from shelter_manager import ShelterManager

def main():
    shelter = ShelterManager()
    
    while True:
        print("\n=== Система учета животных в питомнике ===")
        print("1. Добавить новое животное")
        print("2. Показать всех животных")
        print("3. Поиск животных")
        print("4. Обновить статус животного")
        print("5. Добавить сотрудника")
        print("6. Показать статистику")
        print("7. Выйти")
        
        choice = input("Выберите действие: ")
        
        if choice == '1':
            shelter.add_new_animal()
        elif choice == '2':
            shelter.display_all_animals()
        elif choice == '3':
            shelter.search_animals_menu()
        elif choice == '4':
            shelter.update_animal_status()
        elif choice == '5':
            shelter.add_employee()
        elif choice == '6':
            shelter.display_statistics()
        elif choice == '7':
            print("До свидания!")
            break
        else:
            print("Некорректный выбор. Попробуйте снова.")

if __name__ == "__main__":
    main()