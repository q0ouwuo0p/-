from datetime import datetime
from database import DatabaseManager
from models import Animal, Employee

class ShelterManager:
    def __init__(self):
        self.db = DatabaseManager()

    def add_new_animal(self):
        """Добавление нового животного через интерфейс"""
        print("\n--- Добавление нового животного ---")
        
        name = input("Имя животного: ")
        species = input("Вид (собака, кошка, etc): ")
        breed = input("Порода: ")
        age = int(input("Возраст: "))
        gender = input("Пол (м/ж): ")
        health_status = input("Состояние здоровья: ")
        vaccinated = input("Вакцинирован? (да/нет): ").lower() == 'да'
        notes = input("Примечания: ")
        
        arrival_date = datetime.now().strftime("%Y-%m-%d")
        
        animal = Animal(
            id=None,
            name=name,
            species=species,
            breed=breed,
            age=age,
            gender=gender,
            arrival_date=arrival_date,
            health_status=health_status,
            vaccinated=vaccinated,
            adopted=False,
            notes=notes
        )
        
        animal_id = self.db.add_animal(animal)
        print(f"Животное добавлено с ID: {animal_id}")

    def display_all_animals(self):
        """Отображение всех животных"""
        animals = self.db.get_all_animals()
        
        print("\n--- Все животные в питомнике ---")
        if not animals:
            print("Животных нет в базе данных")
            return
        
        for animal in animals:
            status = "Усыновлен" if animal.adopted else "В питомнике"
            vaccinated = "Да" if animal.vaccinated else "Нет"
            
            print(f"\nID: {animal.id}")
            print(f"Имя: {animal.name}")
            print(f"Вид: {animal.species}")
            print(f"Порода: {animal.breed}")
            print(f"Возраст: {animal.age}")
            print(f"Пол: {animal.gender}")
            print(f"Дата поступления: {animal.arrival_date}")
            print(f"Состояние здоровья: {animal.health_status}")
            print(f"Вакцинирован: {vaccinated}")
            print(f"Статус: {status}")
            if animal.notes:
                print(f"Примечания: {animal.notes}")
            print("-" * 30)

    def search_animals_menu(self):
        """Меню поиска животных"""
        print("\n--- Поиск животных ---")
        print("1. По виду")
        print("2. По статусу усыновления")
        print("3. По состоянию здоровья")
        
        choice = input("Выберите критерий поиска: ")
        
        filters = {}
        if choice == '1':
            species = input("Введите вид: ")
            filters['species'] = species
        elif choice == '2':
            adopted = input("Усыновлены? (да/нет): ").lower() == 'да'
            filters['adopted'] = adopted
        elif choice == '3':
            health_status = input("Введите состояние здоровья: ")
            filters['health_status'] = health_status
        
        animals = self.db.search_animals(**filters)
        
        print(f"\nНайдено животных: {len(animals)}")
        for animal in animals:
            status = "Усыновлен" if animal.adopted else "В питомнике"
            print(f"ID: {animal.id}, Имя: {animal.name}, Вид: {animal.species}, Статус: {status}")

    def update_animal_status(self):
        """Обновление статуса животного"""
        print("\n--- Обновление статуса животного ---")
        
        try:
            animal_id = int(input("Введите ID животного: "))
            animal = self.db.get_animal_by_id(animal_id)
            
            if not animal:
                print("Животное с таким ID не найдено")
                return
            
            print(f"Текущий статус: {'Усыновлен' if animal.adopted else 'В питомнике'}")
            new_status = input("Изменить статус на 'усыновлен'? (да/нет): ").lower() == 'да'
            
            animal.adopted = new_status
            self.db.update_animal(animal)
            print("Статус обновлен")
            
        except ValueError:
            print("Некорректный ID")

    def add_employee(self):
        """Добавление нового сотрудника"""
        print("\n--- Добавление сотрудника ---")
        
        name = input("Имя сотрудника: ")
        position = input("Должность: ")
        phone = input("Телефон: ")
        email = input("Email: ")
        hire_date = datetime.now().strftime("%Y-%m-%d")
        
        employee = Employee(
            id=None,
            name=name,
            position=position,
            phone=phone,
            email=email,
            hire_date=hire_date
        )
        
        employee_id = self.db.add_employee(employee)
        print(f"Сотрудник добавлен с ID: {employee_id}")

    def display_statistics(self):
        """Отображение статистики"""
        stats = self.db.get_statistics()
        
        print("\n--- Статистика питомника ---")
        print(f"Всего животных: {stats['total_animals']}")
        print(f"Усыновлено: {stats['adopted_animals']}")
        print(f"Доступно для усыновления: {stats['available_animals']}")
        print(f"Всего сотрудников: {stats['total_employees']}")
        
        print("\nЖивотные по видам:")
        for species, count in stats['species_count'].items():
            print(f"  {species}: {count}")