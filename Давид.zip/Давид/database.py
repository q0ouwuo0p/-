import sqlite3
from typing import List, Optional
from models import Animal, Employee

class DatabaseManager:
    def __init__(self, db_name: str = "animal_shelter.db"):
        self.db_name = db_name
        self.init_database()

    def init_database(self):
        """Инициализация базы данных и создание таблиц"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            
            # Таблица животных
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS animals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    species TEXT NOT NULL,
                    breed TEXT NOT NULL,
                    age INTEGER NOT NULL,
                    gender TEXT NOT NULL,
                    arrival_date TEXT NOT NULL,
                    health_status TEXT NOT NULL,
                    vaccinated BOOLEAN NOT NULL,
                    adopted BOOLEAN NOT NULL DEFAULT FALSE,
                    notes TEXT
                )
            ''')
            
            # Таблица сотрудников
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    position TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    email TEXT NOT NULL,
                    hire_date TEXT NOT NULL
                )
            ''')
            
            conn.commit()

    # Методы для работы с животными
    def add_animal(self, animal: Animal) -> int:
        """Добавление нового животного"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO animals (name, species, breed, age, gender, 
                                   arrival_date, health_status, vaccinated, adopted, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (animal.name, animal.species, animal.breed, animal.age, 
                  animal.gender, animal.arrival_date, animal.health_status, 
                  animal.vaccinated, animal.adopted, animal.notes))
            conn.commit()
            return cursor.lastrowid

    def get_all_animals(self) -> List[Animal]:
        """Получение всех животных"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM animals')
            rows = cursor.fetchall()
            
            animals = []
            for row in rows:
                animals.append(Animal(
                    id=row[0], name=row[1], species=row[2], breed=row[3],
                    age=row[4], gender=row[5], arrival_date=row[6],
                    health_status=row[7], vaccinated=bool(row[8]),
                    adopted=bool(row[9]), notes=row[10]
                ))
            return animals

    def get_animal_by_id(self, animal_id: int) -> Optional[Animal]:
        """Получение животного по ID"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM animals WHERE id = ?', (animal_id,))
            row = cursor.fetchone()
            
            if row:
                return Animal(
                    id=row[0], name=row[1], species=row[2], breed=row[3],
                    age=row[4], gender=row[5], arrival_date=row[6],
                    health_status=row[7], vaccinated=bool(row[8]),
                    adopted=bool(row[9]), notes=row[10]
                )
            return None

    def update_animal(self, animal: Animal) -> bool:
        """Обновление данных животного"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE animals 
                SET name=?, species=?, breed=?, age=?, gender=?, 
                    arrival_date=?, health_status=?, vaccinated=?, adopted=?, notes=?
                WHERE id=?
            ''', (animal.name, animal.species, animal.breed, animal.age,
                  animal.gender, animal.arrival_date, animal.health_status,
                  animal.vaccinated, animal.adopted, animal.notes, animal.id))
            conn.commit()
            return cursor.rowcount > 0

    def delete_animal(self, animal_id: int) -> bool:
        """Удаление животного"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM animals WHERE id = ?', (animal_id,))
            conn.commit()
            return cursor.rowcount > 0

    def search_animals(self, **filters) -> List[Animal]:
        """Поиск животных по фильтрам"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            
            query = "SELECT * FROM animals WHERE 1=1"
            params = []
            
            if 'species' in filters:
                query += " AND species = ?"
                params.append(filters['species'])
            
            if 'adopted' in filters:
                query += " AND adopted = ?"
                params.append(filters['adopted'])
            
            if 'health_status' in filters:
                query += " AND health_status = ?"
                params.append(filters['health_status'])
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            animals = []
            for row in rows:
                animals.append(Animal(
                    id=row[0], name=row[1], species=row[2], breed=row[3],
                    age=row[4], gender=row[5], arrival_date=row[6],
                    health_status=row[7], vaccinated=bool(row[8]),
                    adopted=bool(row[9]), notes=row[10]
                ))
            return animals

    # Методы для работы с сотрудниками
    def add_employee(self, employee: Employee) -> int:
        """Добавление нового сотрудника"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO employees (name, position, phone, email, hire_date)
                VALUES (?, ?, ?, ?, ?)
            ''', (employee.name, employee.position, employee.phone, 
                  employee.email, employee.hire_date))
            conn.commit()
            return cursor.lastrowid

    def get_all_employees(self) -> List[Employee]:
        """Получение всех сотрудников"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM employees')
            rows = cursor.fetchall()
            
            employees = []
            for row in rows:
                employees.append(Employee(
                    id=row[0], name=row[1], position=row[2], phone=row[3],
                    email=row[4], hire_date=row[5]
                ))
            return employees

    def get_statistics(self) -> dict:
        """Получение статистики по питомнику"""
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            
            # Общее количество животных
            cursor.execute('SELECT COUNT(*) FROM animals')
            total_animals = cursor.fetchone()[0]
            
            # Количество усыновленных животных
            cursor.execute('SELECT COUNT(*) FROM animals WHERE adopted = 1')
            adopted_animals = cursor.fetchone()[0]
            
            # Количество животных по видам
            cursor.execute('SELECT species, COUNT(*) FROM animals GROUP BY species')
            species_count = dict(cursor.fetchall())
            
            # Количество сотрудников
            cursor.execute('SELECT COUNT(*) FROM employees')
            total_employees = cursor.fetchone()[0]
            
            return {
                'total_animals': total_animals,
                'adopted_animals': adopted_animals,
                'available_animals': total_animals - adopted_animals,
                'species_count': species_count,
                'total_employees': total_employees
            }