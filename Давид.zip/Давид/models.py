from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class Animal:
    id: Optional[int]
    name: str
    species: str
    breed: str
    age: int
    gender: str
    arrival_date: str
    health_status: str
    vaccinated: bool
    adopted: bool
    notes: Optional[str]

@dataclass
class Employee:
    id: Optional[int]
    name: str
    position: str
    phone: str
    email: str
    hire_date: str